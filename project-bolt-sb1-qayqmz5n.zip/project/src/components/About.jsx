import React from 'react';

export default function About() {
  return (
    <section id="over-ons" className="py-20 bg-gray-50">
      {/* Existing content */}
    </section>
  );
}