import React from 'react';
import { Link } from 'react-scroll';

export default function Header() {
  return (
    <header className="fixed w-full bg-white shadow-md z-50">
      {/* Existing content */}
    </header>
  );
}