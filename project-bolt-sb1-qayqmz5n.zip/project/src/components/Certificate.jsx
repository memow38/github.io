import React from 'react';

export default function Certificate() {
  return (
    <section id="certificaat" className="py-20 bg-white">
      {/* Existing content */}
    </section>
  );
}